#include<stdio.h>

int main()
{
	float c,a; //cel and a is ferenite
	a=25;

	c=(a*1.8)+32;
	printf(" converted value is%f",c);
}
