#include<stdio.h>

void main()
{
	int no=45;
	if(no%2==0)
	printf("no %d is even ",no);
	else
	printf("no %d is odd",no);
}
