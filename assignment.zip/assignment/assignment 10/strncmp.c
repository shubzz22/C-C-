#include<stdio.h>
#include<string.h>

void main()
{
	      char a1[]="java";
	      char b1[]="aaa";
	      int i=0,count=1;
	      while(a1[i]!='\0')
	      {
	      		  
	      	if(a1[i]==b1[i])
	      	{
		    
	      	count=0;
	      	i++;
	       }
	      	else
		  }
		  if(count==0)
		  printf("same");
	      
}