#include<stdio.h>
void convert();
void main()
{
	convert();
}
void convert()
 {
 	float c,a; //cel and a is ferenite
	a=2;
	
	c=(a*1.8)+32;
	printf(" converted value is %f",c);
 }
