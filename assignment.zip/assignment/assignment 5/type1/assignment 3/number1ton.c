#include<stdio.h>
void number();
  void main()
  {
   number();
  }
  void number(){
  	int no=1;
  	while(no<=10)
  	{
  		printf("%d \n",no);
  		no++;
	}
  	
  }
