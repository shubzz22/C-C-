#include<stdio.h>
#include<string.h>
void main()
{
	char str[]="abcde";
	char str1[]="dcsa";
	int res=strcmp(str1,str);
	 printf("%d",res);
}