//strcpy
#include<stdio.h>
#include<string.h>
void main()
{
	char str[]="world";//two parameters required
	char des[20];
	strcpy(des,str);//datatype type is char and char
	printf("%s",des);	
}