  #include<stdio.h>
  #include<string.h>
  void main()
  {
  	char str[]={'h','e','l','l','o'};
  	int len=strlen(str);
  	printf("%d",len);
  }
  