#include<stdio.h>
#include<string.h>
void main()
{
	char str[]="FIRSTBIT";
  //  char ans[20]=strlwr(str);
    printf("%s",strlwr(str));
    
}
