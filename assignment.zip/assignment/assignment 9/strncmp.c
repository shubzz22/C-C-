#include<stdio.h>
#include<string.h>

void main()
{
	      char a1[]="java";
	      char b1[]="jaaa";
	      int result=strncmp(a1,b1,2);
	      printf("%d",result);
	      
}