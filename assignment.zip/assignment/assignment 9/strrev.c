#include<stdio.h>
#include<string.h>

void main()
{
	      char arr[]= "firstbitsolution";
	 	  printf("%s",strrev(arr));
	                         }