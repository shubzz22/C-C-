#include<stdio.h>
#include<string.h>
void main()
{
	char str[]="firstbit";
  //  char ans[20]=strlwr(str);
    printf("%s",strupr(str));
    
}
